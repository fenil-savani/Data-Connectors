"""Utility module."""

import inspect
import logging
import time
from SharedCode.armis_exceptions import ArmisException
import requests
from . import consts
from .keyvault_secrets_management import KeyVaultSecretManager


class Utils:
    """Utils Class."""

    def __init__(self) -> None:
        """Init Function."""
        self.retry_count = 0
        self.header = {}
        self.check_environment_var_exist(
            [
                {"ArmisURL": consts.URL},
                {"ArmisSecretKey": consts.API_KEY},
                {"AzureWebJobsStorage": consts.CONNECTION_STRING},
            ]
        )
        self._secret_key = consts.API_KEY
        self.keyvault_obj = KeyVaultSecretManager()
        self.access_token_key = "armis-access-token"
        properties_list = self.keyvault_obj.get_properties_list_of_secrets()
        if self.access_token_key in properties_list:
            self.access_token = self.keyvault_obj.get_keyvault_secret(self.access_token_key)
            self.header.update({"Authorization": self.access_token})
        else:
            self.get_access_token()

    def check_environment_var_exist(self, environment_var):
        """Check the existence of required environment variables.

        Args:
            environment_var(list) : variables to check for existence
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            logging.info(consts.LOG_FORMAT.format(__method_name, "Validating Environment Variables."))
            missing_required_field = False
            for var in environment_var:
                key, val = next(iter(var.items()))
                if not val:
                    missing_required_field = True
                    logging.error(
                        consts.LOG_FORMAT.format(__method_name, "Environment variable {} is not set.".format(key))
                    )
            if missing_required_field:
                logging.error(consts.LOG_FORMAT.format(__method_name, "Environment Variables validation failed."))
                raise ArmisException()
            logging.info(consts.LOG_FORMAT.format(__method_name, "Environment Variables validation Success."))
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(__method_name, "Error while checking environment variables: {}".format(err))
            )
            raise ArmisException()

    def compare_access_token(self):
        """Compare the current access token with the keyvault token and refresh if needed."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            keyvault_access_token = self.keyvault_obj.get_keyvault_secret(self.access_token_key)
            header_access_token = self.header.get("Authorization")
            if keyvault_access_token == header_access_token:
                logging.info(consts.LOG_FORMAT.format(
                    __method_name, "KeyVault Access Token Invalid. Generating New Token."
                ))
                self.get_access_token()
            else:
                logging.info(consts.LOG_FORMAT.format(
                    __method_name, "KeyVault Access Token Updated. Updating Header Value."
                ))
                self.header.update({"Authorization": keyvault_access_token})
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Unexpected error : {}.".format(err),
                )
            )
            raise ArmisException()

    def make_rest_call(self, method, url, params=None, headers=None, data=None,
                       retry_401=0, retry_429=0, retry_connection_error=0):
        """Make a rest call with configurable retries for 401, 429, and connection errors.

        Args:
            url (str): The URL to make the call to.
            method (str): The HTTP method to use for the call.
            params (dict, optional): The parameters to pass in the call (default is None).
            headers (dict, optional): The headers to pass in the call (default is None).
            data (dict, optional): The body of the request (default is None).
            retry_401 (int): Number of retries on 401 Unauthorized (default is 0).
            retry_429 (int): Number of retries on 429 Too Many Requests (default is 0).
            retry_connection_error (int): Number of retries on HTTP connection loss (default is 0).

        Returns:
            dict: The JSON response if the call is successful.
        """
        __method_name = inspect.currentframe().f_code.co_name
        attempts_401 = 0
        attempts_429 = 0
        attempts_conn = 0
        try:
            while True:
                try:
                    response = requests.request(
                        method, url, headers=self.header, params=params, data=data,
                        timeout=consts.REQUEST_TIMEOUT,
                    )
                except requests.ConnectionError as err:
                    if attempts_conn < retry_connection_error:
                        attempts_conn += 1
                        logging.warning(
                            consts.LOG_FORMAT.format(
                                __method_name,
                                "HTTP connection lost. Retrying ({}/{}) in {}s: {}.".format(
                                    attempts_conn, retry_connection_error,
                                    consts.RETRY_WAIT_CONNECTION_ERROR, err,
                                ),
                            )
                        )
                        time.sleep(consts.RETRY_WAIT_CONNECTION_ERROR)
                        continue
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Connection error after {} retries: {}.".format(attempts_conn, err),
                        )
                    )
                    raise ArmisException()

                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 400:
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Bad Request = {}, Status code : {}.".format(
                                response.text, response.status_code
                            ),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 401:
                    if attempts_401 < retry_401:
                        attempts_401 += 1
                        self.retry_count += 1
                        logging.warning(
                            consts.LOG_FORMAT.format(
                                __method_name,
                                "Unauthorized (401). Refreshing token and retrying ({}/{})...".format(
                                    attempts_401, retry_401
                                ),
                            )
                        )
                        self.compare_access_token()
                        continue
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Unauthorized (401). Max retries ({}) exceeded.".format(retry_401),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 429:
                    if attempts_429 < retry_429:
                        attempts_429 += 1
                        wait = int(response.headers.get("Retry-After", consts.RETRY_WAIT_429))
                        logging.warning(
                            consts.LOG_FORMAT.format(
                                __method_name,
                                "Rate limited (429). Retrying ({}/{}) after {}s...".format(
                                    attempts_429, retry_429, wait
                                ),
                            )
                        )
                        time.sleep(wait)
                        continue
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Rate limited (429). Max retries ({}) exceeded.".format(retry_429),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 500:
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Internal Server Error, Status code : {}.".format(response.status_code),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 502:
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Bad Gateway, Status code : {}.".format(response.status_code),
                        )
                    )
                    raise ArmisException()
                else:
                    logging.error(
                        consts.LOG_FORMAT.format(
                            __method_name,
                            "Unexpected Error = {}, Status code : {}.".format(
                                response.text, response.status_code
                            ),
                        )
                    )
                    raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except requests.HTTPError as err:
            logging.error(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "HTTP error : {}.".format(err),
                )
            )
            raise ArmisException()
        except requests.Timeout as err:
            logging.error(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Timeout error : {}.".format(err),
                )
            )
            raise ArmisException()
        except requests.exceptions.InvalidURL as err:
            logging.error(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Invalid URL error : {}.".format(err),
                )
            )
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Unexpected error : {}.".format(err),
                )
            )
            raise ArmisException()

    def get_formatted_time(self, alert_time):
        """Format alert time.

        Args:
            alert_time (str): time to format

        Returns:
            str: formatted time
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if len(alert_time) != 19:
                if len(alert_time) == 10:
                    alert_time += "T00:00:00"
                    logging.info(
                        consts.LOG_FORMAT.format(__method_name, "'T:00:00:00' added as only date is available.")
                    )
                else:
                    splited_time = alert_time.split("T")
                    if len(splited_time[1]) == 5:
                        splited_time[1] += ":00"
                        logging.info(consts.LOG_FORMAT.format(__method_name, "':00' added as seconds not available."))
                    elif len(splited_time[1]) == 2:
                        splited_time[1] += ":00:00"
                        logging.info(
                            consts.LOG_FORMAT.format(__method_name, "':00:00' added as only hour is available.")
                        )
                    alert_time = "T".join(splited_time)
            return alert_time
        except KeyError as err:
            logging.error(consts.LOG_FORMAT.format(__method_name, "Key error : {}.".format(err)))
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(__method_name, "Error while formatting time : {}.".format(err))
            )
            raise ArmisException()

    def get_access_token(self):
        """Fetch the access token from Armis API and store it in the header and keyvault."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            body = {"secret_key": self._secret_key}
            logging.info(consts.LOG_FORMAT.format(__method_name, "Getting access token."))
            response = self.make_rest_call(method="POST", url=consts.URL + consts.ACCESS_TOKEN_SUFFIX, data=body)
            access_token = response.get("data", {}).get("access_token")
            self.header.update({"Authorization": access_token})
            self.keyvault_obj.set_keyvault_secret(self.access_token_key, access_token)
            logging.info(consts.LOG_FORMAT.format(__method_name, "Generated access token Successfully."))
        except KeyError as err:
            logging.error(consts.LOG_FORMAT.format(__method_name, "Key error : {}.".format(err)))
            raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(__method_name, "Error while generating the access token : {}.".format(err))
            )
            raise ArmisException()
