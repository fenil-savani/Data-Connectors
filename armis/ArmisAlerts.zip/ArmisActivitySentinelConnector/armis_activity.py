import logging
import time
import inspect
from concurrent.futures import ThreadPoolExecutor, as_completed
from SharedCode.exports_store import ExportsTableStore
from SharedCode.sentinel import send_data_to_sentinel, get_sentinel_client
from SharedCode.utils import Utils
from SharedCode import consts
from SharedCode.armis_exceptions import ArmisException, ArmisTimeOutException


class ArmisActivity(Utils):
    """Reads pre-chunked activity UUID batches written by the Alert function, fetches the
    corresponding activity records from the Armis API, ingests them to Sentinel, and then
    deletes each processed row from the table."""

    def __init__(self, start_time):
        """Initialize the ArmisActivity object."""
        super().__init__()
        self.start_time = start_time
        self.total_activities_posted = 0
        self.check_environment_var_exist(
            [{"ArmisActivitiesTableName": consts.ARMIS_ACTIVITIES_TABLE}]
        )

    def fetch_activities_for_uuids(self, activity_uuids):
        """Fetch activity records from the Armis API for the given list of UUIDs.

        Args:
            activity_uuids (list): activity UUIDs to fetch (at most CHUNK_SIZE per call).

        Returns:
            list: activity records enriched with armis_activity_time, activity_type, activity_title.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            parameters = {
                "aql": "in:activity UUID:{}".format(activity_uuids),
                "from": 0,
                "length": consts.CHUNK_SIZE,
                "fields": ",".join(consts.ACTIVITY_FIELDS),
            }
            results = self.make_rest_call(
                method="GET",
                url=consts.URL + consts.SEARCH_SUFFIX,
                params=parameters,
                headers=self.header,
                retry_401=consts.RETRY_COUNT_401,
                retry_429=consts.RETRY_COUNT_429,
            )
            if ("data" in results) and ("count" in results["data"]) and (results["data"].get("count") == 0):
                logging.warning(
                    consts.LOG_FORMAT.format(__method_name, "Activity data not found for the given UUIDs.")
                )
                return []
            if ("results" in results["data"]) and ("total" in results["data"]) and ("next" in results["data"]):
                data = results["data"]["results"]
                for item in data:
                    item["armis_activity_time"] = item["time"]
                    item["activity_type"] = item["type"]
                    item["activity_title"] = item["title"]
                return data
            else:
                logging.error(
                    consts.LOG_FORMAT.format(__method_name, "Unexpected response structure in activity data.")
                )
                raise ArmisException()

        except KeyError as err:
            logging.error(consts.LOG_FORMAT.format(__method_name, "Key error : {}.".format(err)))
            raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(__method_name, "Error fetching activities : {}.".format(err))
            )
            raise ArmisException()

    def _process_single_row(self, row, activity_uuids_table, sentinel_client):
        """Fetch, ingest, and delete one activity UUID row.

        Returns:
            int: number of activities ingested (0 if row was empty or fetch returned nothing).
        """
        __method_name = inspect.currentframe().f_code.co_name
        pk = row["PartitionKey"]
        rk = row["RowKey"]
        raw_uuids = row.get("activity_uuids", "")

        if not raw_uuids:
            activity_uuids_table.delete(pk, rk)
            return 0

        activity_data = self.fetch_activities_for_uuids(raw_uuids)
        if activity_data:
            send_data_to_sentinel(activity_data, consts.ARMIS_ACTIVITIES_TABLE, client=sentinel_client)
            logging.info(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Ingested {} activities from row {}/{}.".format(len(activity_data), pk, rk),
                )
            )
        activity_uuids_table.delete(pk, rk)
        return len(activity_data) if activity_data else 0

    def process_activity_uuids(self, activity_uuids_table, sentinel_client):
        """Read all pending rows from the activity UUIDs table and ingest activities in parallel.

        Rows are processed concurrently with ACTIVITY_WORKER_COUNT threads — each row triggers
        one Armis API call and one Sentinel upload.  Failed rows are logged and left in the
        table so they are retried on the next run.

        Args:
            activity_uuids_table (ExportsTableStore): table holding pending activity UUID batches.
            sentinel_client: pre-built LogsIngestionClient shared across all worker threads.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            rows = list(activity_uuids_table.list_all())
            if not rows:
                logging.info(
                    consts.LOG_FORMAT.format(__method_name, "No pending activity UUID rows to process.")
                )
                return

            logging.info(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Processing {} pending row(s) with {} worker(s).".format(
                        len(rows), consts.ACTIVITY_WORKER_COUNT
                    ),
                )
            )
            failed = 0
            timed_out = False

            with ThreadPoolExecutor(max_workers=consts.ACTIVITY_WORKER_COUNT) as executor:
                futures = {}
                for row in rows:
                    if int(time.time()) >= self.start_time + consts.FUNCTION_APP_TIMEOUT_SECONDS:
                        timed_out = True
                        break
                    futures[executor.submit(
                        self._process_single_row, row, activity_uuids_table, sentinel_client
                    )] = row

                for future in as_completed(futures):
                    try:
                        self.total_activities_posted += future.result()
                    except ArmisException:
                        row = futures[future]
                        logging.error(
                            consts.LOG_FORMAT.format(
                                __method_name,
                                "Row {}/{} failed; will be retried on next run.".format(
                                    row["PartitionKey"], row["RowKey"]
                                ),
                            )
                        )
                        failed += 1

            if failed:
                logging.warning(
                    consts.LOG_FORMAT.format(
                        __method_name,
                        "{}/{} row(s) failed. They remain in the table for retry.".format(
                            failed, len(rows)
                        ),
                    )
                )
            if timed_out:
                raise ArmisTimeOutException()

        except ArmisTimeOutException:
            raise ArmisTimeOutException()
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(
                    __method_name, "Error processing activity UUIDs : {}.".format(err)
                )
            )
            raise ArmisException()

    def run(self):
        """Set up the activity UUIDs table, create a shared Sentinel client, and process all pending rows."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            activity_uuids_table = ExportsTableStore(
                connection_string=consts.CONNECTION_STRING,
                table_name=consts.ACTIVITY_UUIDS_TABLE_NAME,
            )
            activity_uuids_table.create()
            sentinel_client = get_sentinel_client()
            self.process_activity_uuids(activity_uuids_table, sentinel_client)
            logging.info(
                consts.LOG_FORMAT.format(
                    __method_name,
                    "Total activities posted: {}.".format(self.total_activities_posted),
                )
            )
        except ArmisException:
            raise ArmisException()
        except ArmisTimeOutException:
            logging.warning(
                consts.LOG_FORMAT.format(
                    __method_name, "9:30 mins executed hence stopping the execution."
                )
            )
            return
        except Exception as err:
            logging.error(
                consts.LOG_FORMAT.format(__method_name, "Error occurred during run : {}.".format(err))
            )
            raise ArmisException()
