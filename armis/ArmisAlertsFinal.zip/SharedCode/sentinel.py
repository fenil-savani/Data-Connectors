"""Module for posting data to Azure Sentinel via the Logs Ingestion API."""

from azure.identity import ClientSecretCredential, AzureAuthorityHosts
from azure.monitor.ingestion import LogsIngestionClient
from azure.core.exceptions import HttpResponseError, ClientAuthenticationError
from .consts import (
    DCR_RULE_ID,
    AZURE_DATA_COLLECTION_ENDPOINT,
    SCOPE,
    AZURE_CLIENT_ID,
    AZURE_CLIENT_SECRET,
    AZURE_TENANT_ID,
    LOG_FORMAT,
)
import logging
from .armis_exceptions import ArmisException
import inspect


def get_sentinel_client():
    """Create and return a LogsIngestionClient for reuse across multiple uploads.

    Returns:
        LogsIngestionClient: authenticated client ready for upload calls.
    """
    if SCOPE and ".us" in SCOPE:
        creds = ClientSecretCredential(
            client_id=AZURE_CLIENT_ID,
            client_secret=AZURE_CLIENT_SECRET,
            tenant_id=AZURE_TENANT_ID,
            authority=AzureAuthorityHosts.AZURE_GOVERNMENT,
        )
    else:
        creds = ClientSecretCredential(
            client_id=AZURE_CLIENT_ID,
            client_secret=AZURE_CLIENT_SECRET,
            tenant_id=AZURE_TENANT_ID,
        )
    return LogsIngestionClient(
        AZURE_DATA_COLLECTION_ENDPOINT, credential=creds, credential_scopes=[SCOPE]
    )


def send_data_to_sentinel(data, data_table, client=None):
    """Post data to Azure Sentinel via the ingestion API.

    Args:
        data (dict or list): Data to be ingested into Sentinel.
        data_table (str): Log type/table name for ingestion.
        client (LogsIngestionClient, optional): Pre-built client to reuse.
            Creates a new one if not provided.

    Raises:
        ArmisException: For any error during data upload to Sentinel.
    """
    __method_name = inspect.currentframe().f_code.co_name
    try:
        azure_client = client if client is not None else get_sentinel_client()
        if not isinstance(data, list):
            data = [data] if isinstance(data, dict) else list(data)
        dcr_stream = "Custom-{}".format(data_table)
        azure_client.upload(rule_id=DCR_RULE_ID, stream_name=dcr_stream, logs=data)
    except ClientAuthenticationError as error:
        logging.error(
            LOG_FORMAT.format(
                __method_name, "Authentication error while uploading data to Sentinel."
            )
        )
        raise ArmisException(
            "Authentication error while uploading data to Sentinel: {}".format(error)
        )
    except HttpResponseError as error:
        logging.error(
            LOG_FORMAT.format(
                __method_name, "HTTP response error while uploading data to Sentinel."
            )
        )
        raise ArmisException(
            "HTTP response error while uploading data to Sentinel: {}".format(error)
        )
    except Exception as error:
        logging.error(
            LOG_FORMAT.format(
                __method_name, "Unexpected error while uploading data to Sentinel."
            )
        )
        raise ArmisException(
            "Unexpected error while uploading data to Sentinel: {}".format(error)
        )
