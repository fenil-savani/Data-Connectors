import json
import logging
import time
import inspect

from SharedCode.exports_store import ExportsTableStore
from SharedCode.sentinel import send_data_to_sentinel
from SharedCode.utils import Utils
from SharedCode import consts
from SharedCode.armis_exceptions import (
    ArmisException,
    ArmisDataNotFoundException,
    ArmisTimeOutException,
)


class ArmisAlert(Utils):
    """Fetches alerts from Armis via cursor pagination, ingests them to Sentinel,
    and stores collected activity UUIDs in the activity UUIDs table for async processing.
    """

    def __init__(self, start_time):
        """Initialize the ArmisAlert object."""
        super().__init__(log_format=consts.ALERT_LOG_FORMAT)
        self.start_time = start_time
        self.total_alerts_posted = 0
        self.check_environment_var_exist(
            [{"ArmisAlertsTableName": consts.ARMIS_ALERTS_TABLE}]
        )

    def get_alert_data(self, parameter):
        """Fetch one page of alert data from the Armis API.

        Args:
            parameter (dict): Query parameters including aql, length, and optionally cursor.

        Returns:
            tuple: (list of alerts, next_cursor, count_in_page)
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            results = self.make_rest_call(
                method="GET",
                url=consts.URL + consts.SEARCH_SUFFIX,
                params=parameter,
                headers=self.header,
                retry_401=consts.RETRY_COUNT_401,
                retry_429=consts.RETRY_COUNT_429
            )
            if (
                ("data" in results)
                and ("count" in results["data"])
                and (results["data"].get("count") == 0)
            ):
                raise ArmisDataNotFoundException(
                    consts.ALERT_LOG_FORMAT.format(__method_name, "Alert Data not found.")
                )

            if (
                ("results" in results["data"])
                and ("total" in results["data"])
                and ("next" in results["data"])
            ):
                count_per_page = results["data"]["count"]
                data = results["data"]["results"]
                for alert in data:
                    alert["armis_alert_time"] = alert["time"]
                    alert["alert_type"] = alert["type"]
                    alert["alert_title"] = alert["title"]
                next_cursor = results["data"]["nextCursor"]
                return data, next_cursor, count_per_page
            else:
                logging.error(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "API response missing expected keys ('results', 'total', 'next'). Cannot parse alert page.",
                    )
                )
                raise ArmisException()

        except KeyError as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Unexpected key missing in API response: {}. Check Armis API schema.".format(err),
                )
            )
            raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except ArmisDataNotFoundException as err:
            logging.info(err)
            raise ArmisDataNotFoundException()
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Failed to fetch alerts from Armis API: {}.".format(err),
                )
            )
            raise ArmisException()

    def _store_activity_uuids(self, alert, activity_uuids_table: ExportsTableStore):
        """Store activity UUIDs for an alert as pre-chunked rows in the activity UUIDs table.

        Each row stores at most CHUNK_SIZE UUIDs so the Activity function can process
        one row with a single API call without further splitting.

        Args:
            alert (dict): alert record containing alertId and activityUUIDs.
            activity_uuids_table (ExportsTableStore): table to write UUID batches into.

        Returns:
            int: number of activity UUIDs stored.
        """
        __method_name = inspect.currentframe().f_code.co_name
        alert_id = str(alert.get("alertId", ""))
        activity_uuids = alert.get("activityUUIDs", [])
        if not activity_uuids:
            return 0
        for chunk_idx, start in enumerate(
            range(0, len(activity_uuids), consts.CHUNK_SIZE)
        ):
            chunk = activity_uuids[start : start + consts.CHUNK_SIZE]
            row_key = "{}_{}".format(alert_id, chunk_idx)
            activity_uuids_table.merge(
                "activityuuids", row_key, {"activity_uuids": ",".join(chunk)}
            )
        logging.info(
            consts.ALERT_LOG_FORMAT.format(
                __method_name,
                "Stored {} activity UUIDs for alert ID {} in activity UUIDs table.".format(
                    len(activity_uuids), alert_id
                ),
            )
        )
        return len(activity_uuids)

    def _process_alert_page(
        self,
        alerts,
        next_cursor,
        checkpoint_table: ExportsTableStore,
        activity_uuids_table: ExportsTableStore,
    ):
        """Ingest a page of alerts to Sentinel and store their activity UUIDs.

        Saves next_cursor to the checkpoint table after successful processing so the
        next run continues from the following page, not the current one.

        Args:
            alerts (list): alert records for the current page.
            next_cursor: cursor returned by the API for the next page.
            checkpoint_table (ExportsTableStore): checkpoint table.
            activity_uuids_table (ExportsTableStore): activity UUIDs table.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.total_alerts_posted += len(alerts)
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Processing {} alerts to Sentinel.".format(len(alerts))
                )
            )
            for alert in alerts:
                if (
                    int(time.time())
                    >= self.start_time + consts.FUNCTION_APP_TIMEOUT_SECONDS
                ):
                    raise ArmisTimeOutException()
                self._store_activity_uuids(alert, activity_uuids_table)
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Storing Cursor for next iteration"
                )
            )
            send_data_to_sentinel(alerts, consts.ARMIS_ALERTS_TABLE)
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Ingested {} alerts to Sentinel.".format(len(alerts))
                )
            )
            checkpoint_table.merge("armisalert", "alertcheckpoint", {"cursor": next_cursor})
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Saved next cursor '{}' to checkpoint.".format(next_cursor)
                )
            )
        except ArmisException:
            raise ArmisException()
        except ArmisTimeOutException:
            raise ArmisTimeOutException()
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Error processing alert page : {}.".format(err)
                )
            )
            raise ArmisException()

    def fetch_alerts(self, checkpoint_table, activity_uuids_table, cursor):
        """Paginate through all alerts using cursor, processing each page.

        Args:
            checkpoint_table (ExportsTableStore): checkpoint table for cursor persistence.
            activity_uuids_table (ExportsTableStore): table to store collected activity UUIDs.
            cursor: initial cursor from checkpoint (None = start from beginning).
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if consts.SEVERITY in consts.SEVERITIES:
                severity_index = consts.SEVERITIES.index(consts.SEVERITY)
                included_severities = ",".join(consts.SEVERITIES[severity_index:])
            else:
                raise ValueError()

            parameter = {
                "aql": "in:alerts severity:{}".format(included_severities),
                "orderBy": "lastAlertUpdateTime",
                "fields": ",".join(consts.ALERT_FIELDS),
                "length": consts.ALERTS_CHUNK,
            }

            while True:
                if (
                    int(time.time())
                    >= self.start_time + consts.FUNCTION_APP_TIMEOUT_SECONDS
                ):
                    raise ArmisTimeOutException()

                if cursor is not None:
                    parameter["cursor"] = cursor
                else:
                    parameter.pop("cursor", None)

                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name, "Fetching alerts with cursor: {}.".format(cursor)
                    )
                )
                alerts, next_cursor, count = self.get_alert_data(parameter)
                self._process_alert_page(
                    alerts, next_cursor, checkpoint_table, activity_uuids_table
                )
                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name, "Processed {} alerts from page.".format(count)
                    )
                )
                cursor = next_cursor
                if (cursor is None) or (count == 0):
                    checkpoint_table.merge(
                        "armisalert", "alertcheckpoint", {"cursor": None}
                    )
                    logging.info(
                        consts.ALERT_LOG_FORMAT.format(
                            __method_name,
                            "All alerts fetched. Cursor reset in checkpoint.",
                        )
                    )
                    break

        except ValueError:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Value Error: Severity must be one of 'Low', 'Medium', 'High', 'Critical'.",
                )
            )
            raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except ArmisDataNotFoundException:
            raise ArmisDataNotFoundException()
        except ArmisTimeOutException:
            raise ArmisTimeOutException()
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Error occurred : {}.".format(err)
                )
            )
            raise ArmisException()

    def run(self):
        """Read checkpoint, initialise tables, and drive the alert fetch loop."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_table = ExportsTableStore(
                connection_string=consts.CONNECTION_STRING,
                table_name=consts.CHECKPOINT_TABLE_NAME,
            )
            checkpoint_table.create()

            activity_uuids_table = ExportsTableStore(
                connection_string=consts.CONNECTION_STRING,
                table_name=consts.ACTIVITY_UUIDS_TABLE_NAME,
            )
            activity_uuids_table.create()

            record = checkpoint_table.get("armisalert", "alertcheckpoint")
            if record is None:
                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "No checkpoint found. Starting from the beginning.",
                    )
                )
                checkpoint_table.post("armisalert", "alertcheckpoint", {"cursor": None})
                cursor = None
            else:
                cursor = record.get("cursor")
                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name, "Resuming with cursor: {}.".format(cursor)
                    )
                )

            self.fetch_alerts(checkpoint_table, activity_uuids_table, cursor)
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Total alerts posted: {}.".format(self.total_alerts_posted),
                )
            )
        except ArmisException:
            raise ArmisException()
        except ArmisTimeOutException:
            logging.warning(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "9:30 mins executed hence stopping the execution."
                )
            )
            return
        except ArmisDataNotFoundException:
            raise ArmisDataNotFoundException()
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Error occurred during run : {}.".format(err)
                )
            )
            raise ArmisException()
