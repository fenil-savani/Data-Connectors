"""Alert function: fetch alerts via cursor pagination, ingest to Sentinel, and store activity UUIDs."""

import datetime
import logging
import time
import inspect
import azure.functions as func
from SharedCode import consts
from SharedCode.armis_exceptions import ArmisException, ArmisDataNotFoundException
from .armis_alert import ArmisAlert


def main(mytimer: func.TimerRequest) -> None:
    """Entry point for the Alert timer-triggered Azure Function.

    Args:
        mytimer (func.TimerRequest): Timer trigger binding.
    """
    __method_name = inspect.currentframe().f_code.co_name
    utc_timestamp = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    logging.info(
        consts.LOG_FORMAT.format(
            __method_name, "Alert function triggered at {}.".format(utc_timestamp)
        )
    )
    start_time = time.time()
    armis_obj = ArmisAlert(start_time)
    try:
        armis_obj.run()
    except ArmisDataNotFoundException:
        logging.warning(
            consts.LOG_FORMAT.format(
                __method_name, "Alert data not found. Stopping execution."
            )
        )
    except ArmisException:
        logging.error(
            consts.LOG_FORMAT.format(
                __method_name, "Alert function failed with ArmisException."
            )
        )
        raise Exception()
    utc_timestamp_final = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    logging.info(
        consts.LOG_FORMAT.format(
            __method_name, "Execution completed at {}.".format(utc_timestamp_final)
        )
    )
    if mytimer.past_due:
        logging.info(consts.LOG_FORMAT.format(__method_name, "The timer is past due!"))
