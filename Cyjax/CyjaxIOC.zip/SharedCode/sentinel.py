"""This module contains methods for uploading indicators to Microsoft Sentinel and logging errors."""

import inspect
import time
import json
import requests
from azure.identity import AzureAuthorityHosts, ClientSecretCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.core.exceptions import HttpResponseError, ClientAuthenticationError
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import (
    CyjaxException,
    SentinelUploadException,
    CyjaxAuthenticationException,
)


class MicrosoftSentinel:
    """Microsoft Sentinel client for Upload Indicator API and Log Ingestion API.

    Handles OAuth 2.0 authentication, STIX indicator batch upload,
    and error log ingestion to custom tables.
    """

    def __init__(self):
        """Initialize the Microsoft Sentinel client and generate OAuth token."""
        self.bearer_token = self.auth_sentinel()
        self.log_format = consts.LOG_FORMAT

    def auth_sentinel(self):
        """Authenticate with Microsoft Sentinel using OAuth 2.0 client credentials flow.

        Returns:
            str: Bearer token for Upload Indicator API.

        Raises:
            CyjaxAuthenticationException: If authentication fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{}(method={}) : {} : Generating Microsoft Sentinel access token.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                )
            )
            azure_auth_url = consts.AZURE_AUTHENTICATION_URL.format(
                consts.AZURE_TENANT_ID
            )
            body = {
                "client_id": consts.AZURE_CLIENT_ID,
                "client_secret": consts.AZURE_CLIENT_SECRET,
                "grant_type": "client_credentials",
                "scope": consts.AUTH_SCOPE,
            }
            response = requests.post(
                url=azure_auth_url, data=body, timeout=consts.REQUEST_TIMEOUT
            )
            if 200 <= response.status_code <= 299:
                json_response = response.json()
                if "access_token" not in json_response:
                    applogger.error(
                        "{}(method={}) : {} : Access token not found in Sentinel API response.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                        )
                    )
                    raise CyjaxAuthenticationException(
                        "Access token not found in Sentinel API response."
                    )
                bearer_token = json_response.get("access_token")
                applogger.info(
                    "{}(method={}) : {} : Microsoft Sentinel access token generated successfully.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                    )
                )
                return bearer_token
            else:
                applogger.error(
                    "{}(method={}) : {} : Error generating Sentinel access token. "
                    "Status Code: {}, Reason: {}".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        response.status_code,
                        response.reason,
                    )
                )
                raise CyjaxAuthenticationException(
                    "Error generating Sentinel access token: status code {}, reason: {}".format(
                        response.status_code, response.reason
                    )
                )
        except CyjaxAuthenticationException:
            raise
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Unexpected error while generating Sentinel access token: {}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    error,
                )
            )
            raise CyjaxAuthenticationException(
                "Unexpected error during Sentinel authentication: {}".format(error)
            )

    def upload_indicators(self, stix_objects):
        """Upload STIX indicator objects to Microsoft Sentinel via Upload Indicator API.

        Args:
            stix_objects (list): List of STIX 2.1 indicator objects (max 100 per batch).

        Returns:
            dict: Dictionary with 'success_count', 'failure_count', and 'failed_indicators'.

        Raises:
            SentinelUploadException: If the upload fails after retries.
        """
        __method_name = inspect.currentframe().f_code.co_name
        success_count = 0
        failure_count = 0
        failed_indicators = []

        batches = [
            stix_objects[i: i + consts.STIX_BATCH_SIZE]
            for i in range(0, len(stix_objects), consts.STIX_BATCH_SIZE)
        ]

        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Uploading {} indicators in {} batches".format(
                    len(stix_objects), len(batches)
                ),
            )
        )

        for batch_index, batch in enumerate(batches):
            result = self._upload_batch(batch, batch_index)
            success_count += result["success_count"]
            failure_count += result["failure_count"]
            failed_indicators.extend(result["failed_indicators"])

        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Upload complete. Success: {}, Failed: {}".format(
                    success_count, failure_count
                ),
            )
        )

        return {
            "success_count": success_count,
            "failure_count": failure_count,
            "failed_indicators": failed_indicators,
        }

    def _upload_batch(self, batch, batch_index):
        """Upload a single batch of STIX indicators to the Upload Indicator API.

        Args:
            batch (list): List of STIX indicator objects (max 100).
            batch_index (int): Index of the current batch for logging.

        Returns:
            dict: Dictionary with 'success_count', 'failure_count', and 'failed_indicators'.
        """
        __method_name = inspect.currentframe().f_code.co_name
        retry_count_429 = 0
        retry_count_401 = 0
        upload_url = consts.UPLOAD_INDICATOR_URL.format(consts.WORKSPACE_ID)

        while retry_count_429 <= consts.MAX_RETRIES and retry_count_401 <= 1:
            try:
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(self.bearer_token),
                }
                request_body = {
                    "sourcesystem": consts.STIX_SOURCE_SYSTEM,
                    "stixobjects": batch,
                }
                response = requests.post(
                    url=upload_url,
                    headers=headers,
                    data=json.dumps(request_body),
                    timeout=consts.REQUEST_TIMEOUT,
                )

                if 200 <= response.status_code <= 299:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "Batch {} uploaded successfully, status code: {}, indicators: {}".format(
                                batch_index, response.status_code, len(batch)
                            ),
                        )
                    )
                    return {
                        "success_count": len(batch),
                        "failure_count": 0,
                        "failed_indicators": [],
                    }

                elif response.status_code == 400:
                    json_response = response.json()
                    errors = json_response.get("errors", [])
                    failed_indices = set()
                    for error_item in errors:
                        record_index = error_item.get("recordIndex")
                        error_messages = error_item.get("errorMessages", [])
                        applogger.warning(
                            self.log_format.format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.FUNCTION_NAME,
                                "Validation error at recordIndex {}: {}".format(
                                    record_index, error_messages
                                ),
                            )
                        )
                        if record_index is not None and record_index < len(batch):
                            failed_indices.add(record_index)

                    failed = [
                        batch[i] for i in failed_indices if i < len(batch)
                    ]
                    succeeded = len(batch) - len(failed)
                    applogger.warning(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "Batch {} partial result: {} succeeded, {} failed validation".format(
                                batch_index, succeeded, len(failed)
                            ),
                        )
                    )
                    return {
                        "success_count": succeeded,
                        "failure_count": len(failed),
                        "failed_indicators": failed,
                    }

                elif response.status_code == 429:
                    retry_count_429 += 1
                    retry_after = response.headers.get("Retry-After")
                    sleep_time = (
                        int(retry_after) if retry_after else consts.SENTINEL_429_SLEEP
                    )
                    applogger.warning(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "Rate limited (429) for batch {}, retry {}/{}, sleeping {} seconds".format(
                                batch_index,
                                retry_count_429,
                                consts.MAX_RETRIES,
                                sleep_time,
                            ),
                        )
                    )
                    time.sleep(sleep_time)

                elif response.status_code == 401:
                    retry_count_401 += 1
                    applogger.warning(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "Unauthorized (401) for batch {}, refreshing token".format(
                                batch_index
                            ),
                        )
                    )
                    self.bearer_token = self.auth_sentinel()

                else:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "Upload failed for batch {}, status code: {}, response: {}".format(
                                batch_index, response.status_code, response.text
                            ),
                        )
                    )
                    return {
                        "success_count": 0,
                        "failure_count": len(batch),
                        "failed_indicators": batch,
                    }

            except (CyjaxAuthenticationException, SentinelUploadException):
                raise
            except requests.exceptions.RequestException as req_err:
                applogger.error(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Request error uploading batch {}: {}".format(
                            batch_index, req_err
                        ),
                    )
                )
                return {
                    "success_count": 0,
                    "failure_count": len(batch),
                    "failed_indicators": batch,
                }
            except Exception as error:
                applogger.error(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Unexpected error uploading batch {}: {}".format(
                            batch_index, error
                        ),
                    )
                )
                return {
                    "success_count": 0,
                    "failure_count": len(batch),
                    "failed_indicators": batch,
                }

        applogger.error(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Max retries exceeded for batch {}".format(batch_index),
            )
        )
        return {
            "success_count": 0,
            "failure_count": len(batch),
            "failed_indicators": batch,
        }

    def send_error_logs(self, error_data):
        """Send enrichment error logs to Sentinel via Log Ingestion API.

        Args:
            error_data (list): List of error log records to ingest into CyjaxIOCEnrichmentErrors_CL.

        Raises:
            CyjaxException: If the error log ingestion fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if not error_data:
                return

            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Sending {} error log records to Sentinel".format(len(error_data)),
                )
            )

            if ".us" in consts.SCOPE:
                creds = ClientSecretCredential(
                    client_id=consts.AZURE_CLIENT_ID,
                    client_secret=consts.AZURE_CLIENT_SECRET,
                    tenant_id=consts.AZURE_TENANT_ID,
                    authority=AzureAuthorityHosts.AZURE_GOVERNMENT,
                )
            else:
                creds = ClientSecretCredential(
                    client_id=consts.AZURE_CLIENT_ID,
                    client_secret=consts.AZURE_CLIENT_SECRET,
                    tenant_id=consts.AZURE_TENANT_ID,
                )

            azure_client = LogsIngestionClient(
                consts.DCE_ENDPOINT,
                credential=creds,
                credential_scopes=[consts.SCOPE],
            )

            if not isinstance(error_data, list):
                error_data = [error_data] if isinstance(error_data, dict) else list(error_data)

            azure_client.upload(
                rule_id=consts.DCR_RULE_ID,
                stream_name=consts.ERROR_DCR_STREAM,
                logs=error_data,
            )

            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Successfully sent {} error log records to Sentinel".format(
                        len(error_data)
                    ),
                )
            )

        except ClientAuthenticationError as error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Authentication error while sending error logs to Sentinel: {}".format(
                        error
                    ),
                )
            )
            raise CyjaxException(
                "Authentication error while sending error logs: {}".format(error)
            )
        except HttpResponseError as error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "HTTP response error while sending error logs to Sentinel: {}".format(
                        error
                    ),
                )
            )
            raise CyjaxException(
                "HTTP response error while sending error logs: {}".format(error)
            )
        except Exception as error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Unexpected error while sending error logs to Sentinel: {}".format(
                        error
                    ),
                )
            )
            raise CyjaxException(
                "Unexpected error while sending error logs: {}".format(error)
            )
