"""This module contains the CyjaxIOCHelper class for IOC collection, enrichment, and orchestration."""

import inspect
import json
import time
from datetime import datetime, timedelta, timezone
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.exceptions import (
    CyjaxException,
    CyjaxTimeoutException,
    CyjaxAuthenticationException,
)
from SharedCode.cyjax_client import CyjaxClient
from SharedCode.cyjax_to_stix_mapping import map_cyjax_ioc_to_stix
from SharedCode.sentinel import MicrosoftSentinel
from SharedCode.state_manager import StateManager


class CyjaxIOCHelper:
    """Orchestrates the full Cyjax IOC collection, enrichment, STIX mapping, and upload flow.

    This class handles:
    - Fetching IOCs from the Cyjax API page by page
    - Enriching each IOC with additional context
    - Mapping IOC + enrichment data to STIX 2.1 indicators
    - Uploading indicators to Microsoft Sentinel via Upload Indicator API
    - Logging failed enrichment lookups to a custom error table
    - Managing checkpoints for incremental fetching
    - Handling function timeout at 9:30 minutes
    """

    def __init__(self, start_time):
        """Initialize the CyjaxIOCHelper with required clients and state.

        Args:
            start_time (int): The Unix timestamp when the function started.
        """
        self.start_time = start_time
        self.log_format = consts.LOG_FORMAT
        self.cyjax_client = CyjaxClient()
        self.sentinel_client = MicrosoftSentinel()
        self.state_manager = StateManager(
            connection_string=consts.CONN_STRING,
            file_path=consts.CHECKPOINT_FILE,
            share_name=consts.FILE_SHARE_NAME,
        )
        self.total_fetched = 0
        self.total_enriched = 0
        self.total_indicators = 0
        self.total_success = 0
        self.total_failed = 0
        self.total_mapping_errors = 0

    def _check_timeout(self):
        """Check if the function is approaching the 9:30 minute timeout.

        Raises:
            CyjaxTimeoutException: If the function has been running for more than 570 seconds.
        """
        elapsed = time.time() - self.start_time
        if elapsed >= consts.FUNCTION_APP_TIMEOUT_SECONDS:
            applogger.warning(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    "_check_timeout",
                    consts.FUNCTION_NAME,
                    "Function approaching timeout at {} seconds. Saving checkpoint and exiting.".format(
                        int(elapsed)
                    ),
                )
            )
            raise CyjaxTimeoutException(
                "Function timeout reached at {} seconds".format(int(elapsed))
            )

    def _get_checkpoint(self):
        """Retrieve the checkpoint data from Azure File Share.

        Returns:
            dict: Checkpoint data with 'since', 'until', and 'page' keys,
                  or None if no checkpoint exists.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_data = self.state_manager.get()
            if checkpoint_data:
                checkpoint = json.loads(checkpoint_data)
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Checkpoint found: {}".format(checkpoint),
                    )
                )
                return checkpoint
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "No checkpoint found. Starting fresh.",
                )
            )
            return None
        except json.JSONDecodeError as json_err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    consts.JSON_DECODE_ERROR_MSG.format(json_err),
                )
            )
            return None
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            return None

    def _save_checkpoint(self, since, until, page):
        """Save the checkpoint data to Azure File Share.

        Args:
            since (str): Start datetime for the current fetch window (ISO8601).
            until (str): End datetime for the current fetch window (ISO8601).
            page (int): Current page number within the window.
        """
        __method_name = inspect.currentframe().f_code.co_name
        checkpoint = {
            "since": since,
            "until": until,
            "page": page,
        }
        try:
            self.state_manager.post(json.dumps(checkpoint))
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Checkpoint saved: {}".format(checkpoint),
                )
            )
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Error saving checkpoint: {}".format(err),
                )
            )

    def _validate_environment_variables(self):
        """Validate that all required environment variables are set.

        Raises:
            CyjaxException: If any required environment variable is missing.
        """
        __method_name = inspect.currentframe().f_code.co_name
        required_vars = {
            "CYJAX_ACCESS_TOKEN": consts.CYJAX_ACCESS_TOKEN,
            "CYJAX_BASE_URL": consts.CYJAX_BASE_URL,
            "AZURE_CLIENT_ID": consts.AZURE_CLIENT_ID,
            "AZURE_CLIENT_SECRET": consts.AZURE_CLIENT_SECRET,
            "AZURE_TENANT_ID": consts.AZURE_TENANT_ID,
            "WORKSPACE_ID": consts.WORKSPACE_ID,
            "AzureWebJobsStorage": consts.CONN_STRING,
        }
        missing = [key for key, val in required_vars.items() if not val]
        if missing:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Missing required environment variables: {}".format(
                        ", ".join(missing)
                    ),
                )
            )
            raise CyjaxException(
                "Missing required environment variables: {}".format(", ".join(missing))
            )
        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "All required environment variables validated.",
            )
        )

    def collect_and_enrich_iocs(self, since, until, page):
        """Fetch a page of IOCs and enrich each one.

        Args:
            since (str): Start datetime (ISO8601).
            until (str): End datetime (ISO8601).
            page (int): Page number to fetch.

        Returns:
            tuple: (list of merged IOC+enrichment dicts, raw IOC list)

        Observability:
            Updates self.total_fetched with the count of raw IOCs retrieved.
            Updates self.total_enriched with the count of IOCs successfully enriched.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Fetching IOCs: since={}, until={}, page={}".format(since, until, page),
            )
        )

        ioc_list = self.cyjax_client.get_indicators(since=since, until=until, page=page)

        if not ioc_list:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "No IOCs returned for page {}".format(page),
                )
            )
            return [], [], []

        self.total_fetched += len(ioc_list)
        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Fetched {} IOCs on page {} (total fetched so far: {})".format(
                    len(ioc_list), page, self.total_fetched
                ),
            )
        )

        merged_records = []
        enriched_values = []
        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Enriching {} IOCs of page {}".format(len(ioc_list), page),
            )
        )
        for ioc in ioc_list:
            self._check_timeout()
            ioc_value = ioc.get("value", "")
            enrichment_data = None

            try:
                enrichment_data = self.cyjax_client.get_enrichment(ioc_value)
                self.total_enriched += 1
                enriched_values.append(ioc_value)
            except CyjaxAuthenticationException as auth_err:
                # Authentication failures will affect all IOCs - stop immediately
                applogger.error(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Enrichment authentication failed: {}. Stopping enrichment for all IOCs.".format(
                            auth_err
                        ),
                    )
                )
                raise
            except Exception as enrich_err:
                applogger.warning(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Enrichment failed for IOC value={}: {}. Continuing.".format(
                            ioc_value, enrich_err
                        ),
                    )
                )

            merged_records.append({"ioc_data": ioc, "enrichment_data": enrichment_data})

        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Enrichment complete for page {}. Succeeded: {} {}, Failed: {}".format(
                    page,
                    len(enriched_values),
                    enriched_values,
                    len(ioc_list) - len(enriched_values),
                ),
            )
        )

        return merged_records, ioc_list

    def process_batch(self, merged_records):
        """Map merged IOC+enrichment records to STIX and upload to Sentinel.

        STIX indicators are uploaded via sentinel_client.upload_indicators(), which internally
        sub-batches at consts.STIX_BATCH_SIZE (100) to comply with the Microsoft Upload
        Indicators API limit. All sub-batches must succeed before the caller advances the
        checkpoint; on any failure the caller should retry the full page.

        Args:
            merged_records (list): List of dicts with 'ioc_data' and 'enrichment_data'.

        Returns:
            dict: Upload result with 'success_count', 'failure_count', 'failed_indicators'.

        Observability:
            Updates self.total_mapping_errors for IOCs that fail STIX mapping.
        """
        __method_name = inspect.currentframe().f_code.co_name
        stix_indicators = []

        for record in merged_records:
            try:
                stix_obj = map_cyjax_ioc_to_stix(
                    ioc_data=record["ioc_data"],
                    enrichment_data=record["enrichment_data"],
                )
                if stix_obj:
                    stix_indicators.append(stix_obj)
            except CyjaxException as map_err:
                self.total_mapping_errors += 1
                applogger.warning(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Skipping IOC due to mapping error: {}".format(map_err),
                    )
                )

        if not stix_indicators:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "No valid STIX indicators to upload.",
                )
            )
            return {"success_count": 0, "failure_count": 0, "failed_indicators": []}

        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Uploading {} STIX indicators to Sentinel in batches of {}".format(
                    len(stix_indicators), consts.STIX_BATCH_SIZE
                ),
            )
        )

        result = self.sentinel_client.upload_indicators(stix_indicators)
        return result

    def run(self):
        """Orchestrate the full Cyjax IOC collection, enrichment, mapping, and upload flow.

        Raises:
            CyjaxTimeoutException: If the function approaches the 9:30 minute timeout.
            CyjaxException: If a critical error occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Starting Cyjax IOC ingestion run.",
            )
        )

        self._validate_environment_variables()

        checkpoint = self._get_checkpoint()
        now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        if checkpoint:
            since = checkpoint.get("since")
            until = checkpoint.get("until")
            page = checkpoint.get("page", 1)
        else:
            lookback = datetime.now(timezone.utc) - timedelta(days=consts.LOOKBACK_DAYS)
            since = lookback.strftime("%Y-%m-%dT%H:%M:%SZ")
            until = now_utc
            page = 1

        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Processing window: since={}, until={}, starting page={}".format(
                    since, until, page
                ),
            )
        )

        while True:
            self._check_timeout()

            merged_records, raw_iocs = self.collect_and_enrich_iocs(since, until, page)

            if not raw_iocs:
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "All pages processed for window since={}, until={}".format(
                            since, until
                        ),
                    )
                )
                new_since = until
                new_until = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                self._save_checkpoint(new_since, new_until, 1)
                break

            if merged_records:
                result = self.process_batch(merged_records)
                attempted = result["success_count"] + result["failure_count"]
                self.total_indicators += attempted
                self.total_success += result["success_count"]
                self.total_failed += result["failure_count"]
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Page {} ingestion complete. Attempted: {}, Succeeded: {}, Failed: {}".format(
                            page,
                            attempted,
                            result["success_count"],
                            result["failure_count"],
                        ),
                    )
                )

            if len(raw_iocs) < consts.CYJAX_PAGE_SIZE:
                # Last page - advance to next time window directly
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Last page reached (received {} < {} items). Window complete.".format(
                            len(raw_iocs), consts.CYJAX_PAGE_SIZE
                        ),
                    )
                )
                new_since = until
                new_until = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                self._save_checkpoint(new_since, new_until, 1)
                break

            # Not the last page - save checkpoint and continue to next page
            page += 1
            self._save_checkpoint(since, until, page)

        applogger.info(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                (
                    "Run complete. "
                    "Fetched: {}, Enriched: {}, "
                    "Mapping errors: {}, "
                    "Attempted ingestion: {}, Succeeded: {}, Failed: {}"
                ).format(
                    self.total_fetched,
                    self.total_enriched,
                    self.total_mapping_errors,
                    self.total_indicators,
                    self.total_success,
                    self.total_failed,
                ),
            )
        )
