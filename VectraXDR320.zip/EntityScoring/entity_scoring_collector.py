"""This entity_scoring_collector file will pull and push the data of entity scoring."""

from ..SharedCode.collector import BaseCollector
from ..SharedCode.state_manager import StateManager
from ..SharedCode.logger import applogger
from SharedCode.vectra_exception import VectraException
from ..SharedCode.consts import (
    ENTITY_SCORING_TABLE_NAME,
    ENTITY_SCORING_ENDPOINT,
    INCLUDE_SCORE_DECREASE,
    ENTITY_SCORING_NAME,
    LOGS_STARTS_WITH
)
import inspect

MODIFIED_FIELDS = ["last_detection"]


class EntityScoringCollector(BaseCollector):
    """This class contains methods to create object and call get checkpoint and 'pull and push the data'method."""

    def __init__(self, function_name, client_id, client_secret) -> None:
        """Initialize instance variable for class."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.access_token_key = "access-token-entityscore"
            self.refresh_token_key = "refresh-token-entityscore"
            self.access_token_expiry = "expires_in_entityscore"
            self.refresh_token_expiry = "refresh_expires_in_entityscore"
            super(EntityScoringCollector, self).__init__(
                function_name, client_id, client_secret
            )
            self.state = StateManager(
                connection_string=self.connection_string, file_path="entity_scoring_account"
            )
            self.entity_scoring_table_name = ENTITY_SCORING_TABLE_NAME
            self.validate_params(
                    "ENTITY_SCORING_CLIENT_ID",
                    "ENTITY_SCORING_CLIENT_SECRET",
            )
            applogger.info(
                "{}(method={}) : {} : Parameter validation successful.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    ENTITY_SCORING_NAME,
                )
            )
            self.validate_connection()
            applogger.info(
                "{}(method={}) : {} : Established connection with Vectra successfully.".format(
                    LOGS_STARTS_WITH,
                    __method_name,
                    ENTITY_SCORING_NAME,
                )
            )
        except VectraException:
            raise VectraException()

    def get_entity_scoring_data_and_ingest_into_sentinel_account(self):
        """To call get checkpoint and 'pull and push the data' method for account data."""
        try:
            params = {"type": "account"}
            if INCLUDE_SCORE_DECREASE == "true":
                params.update({"include_score_decreases": "true"})
            field, checkpoint = self.get_checkpoint_field_and_value()
            self.pull_and_push_the_data(
                ENTITY_SCORING_ENDPOINT,
                field,
                checkpoint,
                self.entity_scoring_table_name,
                query_params=params,
            )
        except VectraException:
            raise VectraException()

    def get_entity_scoring_data_and_ingest_into_sentinel_host(self):
        """To call get checkpoint and 'pull and push the data' method for host data."""
        try:
            self.state = StateManager(
                connection_string=self.connection_string, file_path="entity_scoring_host"
            )
            params = {"type": "host"}
            if INCLUDE_SCORE_DECREASE == "true":
                params.update({"include_score_decreases": "true"})
            field, checkpoint = self.get_checkpoint_field_and_value()
            self.pull_and_push_the_data(
                ENTITY_SCORING_ENDPOINT,
                field,
                checkpoint,
                self.entity_scoring_table_name,
                query_params=params,
            )
        except VectraException:
            raise VectraException()
